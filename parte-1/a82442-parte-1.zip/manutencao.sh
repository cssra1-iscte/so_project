#!/bin/bash
# SO_HIDE_DEBUG=1                   ## Uncomment this line to hide all @DEBUG statements
# SO_HIDE_COLOURS=1                 ## Uncomment this line to disable all escape colouring
. so_utils.sh                       ## This is required to activate the macros so_success, so_error, and so_debug

#####################################################################################
## ISCTE-IUL: Trabalho prático de Sistemas Operativos 2024/2025, Enunciado Versão 1
##
## Aluno: Nº:  82442     Nome: Carolina Salvador
## Nome do Módulo: S2. Script: manutencao.sh
## Descrição/Explicação do Módulo:
##
## NOTA IMPORTANTE - NÃO TIVE TEMPO DE CORRIGIR AS VALIDAÇÕES. EM TERMOS DE LÓGICA, JULGO QUE ESTEJA A MAIOR PARTE CERTA. IREI PROCEDER A UMA REVISÃO POSTERIOR
#####################################################################################

## Este script não recebe nenhum argumento, e permite realizar a manutenção dos registos de estacionamento. 

## S2.1. Validações do script:
## O script valida se, no ficheiro estacionamentos.txt:
## • Todos os registos referem códigos de países existentes no ficheiro paises.txt;
## • Todas as matrículas registadas correspondem à especificação de formato dos países correspondentes;
## • Todos os registos têm uma data de saída superior à data de entrada;
## • Em caso de qualquer erro das condições anteriores, dá so_error S2.1 <descrição do erro>, indicando o erro em questão, e termina. Caso contrário, dá so_success S2.1.

# Validar códigos países

if [[ ! -f paises.txt ]]; then
    so_error S2.1 "ficheiro paises.txt não existe"
    exit 1
fi

if [[ ! -r paises.txt ]]; then
    so_error S2.1 "ficheiro paises.txt NÃO TEM PERMISSÕES de leitura"
    exit 1
fi

#---
awk -F '###' '{print $1}' paises.txt > paises_autoriz.txt

codigos_validos=$(paste -sd '|' paises_autoriz.txt) #permite colocar todos os codigos válidos numa só linha para se utilizar no grep. Tornando codigos validos numa expressão regular

codigos_invalidos=$(cut -d':' -f2 "estacionamentos.txt" | grep -vE "^($codigos_validos)$" | wc -l) #conta o número de casos inválidos

#echo "Nº de códigos inválidos: $codigos_invalidos"

if [[ $codigos_invalidos != 0 ]]; then
    so_error S2.1 "Existem codigos invalidos"
    echo "$codigos_invalidos"
    echo "$codigos_validos"
    exit 1
fi


# Validar matrículas

while IFS=":" read -r matricula codigo categoria nome entrada saida; do

    regex=$(grep "^$codigo###" paises.txt | awk -F '###' '{print $3}')

    if [[ ! "$matricula" =~ $regex ]]; then
        so_error S2.1 "Matrícula inválida para o país $codigo: $matricula"
        exit 1
        fi

done < estacionamentos.txt

#so_success S2.1 "Matrículas Válidas" # depois é necessário colocar em comentário

# Validar data_saida > data_entrada
#count=0
while IFS=":" read -r matricula codigo categoria nome entrada saida; do
#((count++))
    if [[ -n "$saida" ]]; then
        #echo "linha $count: COM saída"

        entrada_unix=$(date -d "$(echo "$entrada" | sed 's/T/ /; s/h/:/')" +%s) # tempo em segundos
        saida_unix=$(date -d "$(echo "$saida" | sed 's/T/ /; s/h/:/')" +%s) # tempo em segundos 
        #echo "linha $count - entrada unix = $entrada_unix"
        #echo "linha $count - entrada unix = $saida_unix"

        if [[ entrada_unix -ge saida_unix ]]; then
            so_error S2.1 "Ficheiro com datas INVÁLIDAS"
            exit 1
        fi
    fi

done < estacionamentos.txt

so_success S2.1 "Validações corretas"






## S2.2. Processamento:
## • O script move, do ficheiro estacionamentos.txt, todos os registos que estejam completos (com registo de entrada e registo de saída), mantendo o formato do ficheiro original, para ficheiros separados com o nome arquivo-<Ano>-<Mês>.park, com todos os registos agrupados pelo ano e mês indicados pelo nome do ficheiro. Ou seja, os registos são removidos do ficheiro estacionamentos.txt e acrescentados ao correspondente ficheiro arquivo-<Ano>-<Mês>.park, sendo que o ano e mês em questão são os do campo <DataSaída>. 
## • Quando acrescentar o registo ao ficheiro arquivo-<Ano>-<Mês>.park, este script acrescenta um campo <TempoParkMinutos> no final do registo, que corresponde ao tempo, em minutos, que durou esse registo de estacionamento (correspondente à diferença em minutos entre os dois campos anteriores).
## • Em caso de qualquer erro das condições anteriores, dá so_error S2.2 <descrição do erro>, indicando o erro em questão, e termina. Caso contrário, dá so_success S2.2.
## • O registo em cada ficheiro arquivo-<Ano>-<Mês>.park, tem então o formato:
## <Matrícula:string>:<Código País:string>:<Categoria:char>:<Nome do Condutor:string>: <DataEntrada:AAAA-MM-DDTHHhmm>:<DataSaída:AAAA-MM-DDTHHhmm>:<TempoParkMinutos:int>
## • Exemplo de um ficheiro arquivo-<Ano>-<Mês>.park, para janeiro de 2025:



sed -i 's/\r$//' estacionamentos.txt #retira \r do ficheiro estacionamentos.txt

while IFS=":" read -r matricula codigo categoria nome entrada saida; do
   
    if [[ -n "$saida" ]]; then # verifica se a linha possui o campo "saída"
        ano_saida=$(echo "$saida" | awk -F '-' '{print $1}')
        mes_saida=$(echo "$saida" | awk -F '-' '{print $2}')

        ficheiro="arquivo-$ano_saida-$mes_saida.park"


        entrada_unix=$(date -d "$(echo "$entrada" | sed 's/T/ /; s/h/:/')" +%s) # tempo em segundos
        saida_unix=$(date -d "$(echo "$saida" | sed 's/T/ /; s/h/:/')" +%s)

        duracao_park=$(( (saida_unix - entrada_unix) / 60 )) #converter para minutos

        if [[ ! -w $ficheiro ]]; then
            so_error S2.2 "Ficheiro $ficheiro SEM PERMISSÕES DE ESCRITA"
            exit 1
        fi
    
        echo "$matricula:$codigo:$categoria:$nome:$entrada:$saida:$duracao_park" >> "$ficheiro"    
        sed -i "/^$matricula:$codigo:$categoria:$nome:$entrada:$saida$/d" estacionamentos.txt
        
    fi
        
    done < "estacionamentos.txt"
    
    so_success S2.2 "Manutenção efetuada"


